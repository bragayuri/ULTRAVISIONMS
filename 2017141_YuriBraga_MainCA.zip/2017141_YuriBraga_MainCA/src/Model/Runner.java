//Yuri Braga 2017141
// This class is my test class.
//Here it is possible to call each class for test individual changes.

package Model;

import View.AddCustomerPanel;
import View.AddLiveC;
import View.AddMovie;
import View.AddMusicPanel;
import View.AddRental;
import View.AddTitlePanel;
import View.ImageTest;
import View.MainPanel;
import View.ManageARental;
import View.ManageRental;
import View.ManageTitle;
import View.SearchCustomerPanel;
import View.SearchRental;
import View.SearchTitle;
import View.UpdateCustomer;

/*
 * This class will test each single frame of the program individually.
 * All the classed in a comment block can be easily accessed and tested.
 * The start of the main Panel is also from here.
 */

public class Runner {
	
	/*
	 * The main panel will start the program.
	 */

	
	public static void main(String[]args) {
		
		MainPanel mp = new MainPanel();
		
		//ManageRental rental = new ManageRental();
		//ManageTitle mytitle = new ManageTitle();
		//AddTitlePanel mypanel = new AddTitlePanel();
		//AddMusicPanel mypanel2 = new AddMusicPanel();
		//ImageTest mytest = new ImageTest();
		//AddMovie mymovie = new AddMovie();
		//AddCustomerPanel mypanel = new AddCustomerPanel();
		//AddLiveC myc = new AddLiveC();
        //UpdateCustomer newc = new UpdateCustomer();
		//SearchCustomerPanel mysearch = new SearchCustomerPanel();
		//SearchTitle mytitle = new SearchTitle();
		
		//ManageRental rental = new ManageRental();
		//AddRental newrantal = new AddRental();
		//ManageARental x = new ManageARental();
		//SearchRental x= new SearchRental();
		
		
	}
}
