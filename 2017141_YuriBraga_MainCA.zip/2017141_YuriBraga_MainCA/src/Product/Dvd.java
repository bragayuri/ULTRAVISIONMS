package Product;

public interface Dvd {
	
	public void HighqualityVideos();

}
