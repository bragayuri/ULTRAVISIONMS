package Product;

public interface Cd {
	
	public void musicStorage();

}
