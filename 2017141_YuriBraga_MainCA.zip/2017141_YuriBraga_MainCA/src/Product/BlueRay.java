// Yuri Braga 2017141

package Product;

// This is my interface BlueRay. It will be implemented by some types of media.
public interface BlueRay {

	// This method will set this method to specify a blueRay characteristic.
	
	public void ultraHighQualityVideos(String blueray);
	
	String blueray="Blue-Ray";

	void ultraHighQualityVideos();
}
