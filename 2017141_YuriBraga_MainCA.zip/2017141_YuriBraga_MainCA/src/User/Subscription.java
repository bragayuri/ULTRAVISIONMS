// Yuri Braga 20171141   

package User;

// This is my Enum which will define type of subscription.
//Unfortunately I could not implement it.

public enum Subscription {
	MUSICLOVERS,
	TVLOVERS,
	VIDEOLOVERS,
	PREMIUM;

}
